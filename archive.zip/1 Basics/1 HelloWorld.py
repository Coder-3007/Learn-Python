#we will learn how to print helloworld

#  print("hello World")
#  name = input("what is ur name?")
#  print("Nice to meet you",name)


#writing the function

def main ():
 print("hello World")
 name = input("what is ur name?")
 print("Nice to meet you",name)

if __name__ == "__main__":
   main()



